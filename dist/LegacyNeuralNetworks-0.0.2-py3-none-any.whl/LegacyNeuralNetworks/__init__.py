from LegacyNeuralNetworks.Fill import Writer
from LegacyNeuralNetworks.ann_fill import Writer
from LegacyNeuralNetworks.LegacyNeuralNetworks import *