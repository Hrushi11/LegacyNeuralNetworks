from LegacyNeuralNetworks.Fill import Writer
from LegacyNeuralNetworks.LegacyNeuralNetworks import *